const Seneca = require('seneca');
var seneca = Seneca();
const MiniSearch = require('minisearch');
//TODO!