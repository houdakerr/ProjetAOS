const Seneca = require('seneca')
const SenecaWeb = require('seneca-web')
const Express = require('express')
const seneca = Seneca()
const BodyParser = require('body-parser')

// definition des routes /api/wr accessible via des requetes GET, POST,PUT, DELETE

var Routes = [{
  pin: 'role:web,target:wr,cmd:*', // type de message cree a la reception d'une requete HTTP
  prefix : '/api/wr',
  map: {
    stats: {GET: true, suffix:'/:applicant?'}, //cette route "stats" doit être en premier pour ne pas confondre avec l'autre GET 
    create: {POST: true, name: ''},  //accepter les requetes POST
    retrieve: {GET: true, name:'', suffix:'/:id?'}, //accepter les requetes GET
    update: {PUT: true, name:'', suffix:'/:id?'}, //accepter les requetes PUT
    delete: {DELETE: true, name:'',suffix:'/:id?'} //accepter les requetes DELETE
  }
}]

seneca.use(SenecaWeb, {
  options: { parseBody: false }, // desactive l'analyseur JSON de Seneca
  routes: Routes,
  context: Express().use(BodyParser.json()),     // utilise le parser d'Express pour lire les donnees 
  adapter: require('seneca-web-adapter-express') // 
})

 //se connecter au service wr
seneca.client({              // ce module enverra les messages counter:*
              port: 4000,    // sur le port 4000 (qui est le port sur lequel le microservice
              pin:'role:wr'  // wr attend les messages...
            }) 

//se connecter au service stats
seneca.client({                   // ce module enverra les messages counter:*
              port:5000,          // sur le port 4000 (qui est le port sur lequel le microservice
              pin:"role:wr-stats"  // wr attend les messages...
            }) 

/**
 *  cette fonction permet de transferer des messages role:web,target:wr:
 * 
 */
seneca.add('role:web,target:wr', function (msg, respond) {

    let data = msg.args.body;
    let params = msg.args.params;

    this.log.info({pattern: msg.args.route.pattern, data: data, params: params});

 
    
/**
   * si le message est "stats"
   *  Envoyer le messgae "role;wr-stats" au stats-service
   * - soit avec l'action getGlobalStats
   * - soit avec l'action getUserStats
*/  
    if(msg.cmd == "stats") {

      if(!params.applicant) {

        this.act("role:wr-stats,action:getGlobalStats",respond)

      }
      else {
        this.act("role:wr-stats,action:getUserStats,applicant:"+params.applicant,respond)
      }
    }
    else {

      //sionon concaténer les parties de l'url de la requette, après envoyer les message
      msgContent = Object.assign({},data,params)
      msgContent["cmd"] = msg.cmd
      msgContent["role"] = "wr"
      console.log(msgContent)
      this.act(msgContent,respond)
    }
})

// les requetes HTTP sont attendues sur le port 3000
// Pour tester :
// - lancer le service counter.js
// - lancer la passerelle RESTcounter.js
// - et tester avec : curl -H "Content-Type: application/json" -d '{"applicant":"kerr","work":"architecte","dc_date":"13/04/22"}' -X PUT http://localhost:3000/api/wr

seneca.ready(() => {
  const app = seneca.export('web/context')()
  app.listen(3000)
})
