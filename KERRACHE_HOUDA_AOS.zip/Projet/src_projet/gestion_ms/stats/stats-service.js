const Seneca = require('seneca')

var seneca = Seneca()

var DTs_created = 0
var DTs_closed = 0
var DTs_deleted = 0

var created = {}
var closed = {}
var deleted = {}

//recevoir le message de Wr-service , avec l'action "created" on créer file associé
seneca.add("role:wr-stats,action:created", function(msg,done){
    applicant = msg.data.applicant
    //on incrémente le nombre de DT crées 
    DTs_created+=1
    //create the file 
    if(!created[applicant])
    {
        console.log("file is created")
        created[applicant] = 0
        closed[applicant] = 0
        deleted[applicant] = 0
    }
    created[applicant]+=1
    done()
})

//recevoir le message de Wr-service , avec l'action "closed"
seneca.add("role:wr-stats,action:closed", function(msg,done){
    applicant = msg.data.applicant
     //on incrémente le nombre des DTs fermées
    DTs_closed+=1
   
    closed[applicant]+=1
    done()
})

//recevoir le message de Wr-service , avec l'action "deleted"
seneca.add("role:wr-stats,action:deleted", function(msg,done){
    applicant = msg.data.applicant
    //on incrémente la valeur des DTs supprimées 
    DTs_deleted+=1
    deleted[applicant]+=1
    done()
})

//recevoir le message de api , avec l'action "getUserStats"
seneca.add("role:wr-stats,action:getUserStats", function(msg,done){
    
    done(null,{success:true, data:{
        applicant: msg.applicant,
        stats_wr_created:created[msg.applicant],
        stats_wr_opened:created[msg.applicant]-closed[msg.applicant]-deleted[msg.applicant],
        stats_wr_closed: closed[msg.applicant]}})
})

//recevoir le message de api , avec l'action "getGlobalStats" et rtourner les valeurs
seneca.add("role:wr-stats,action:getGlobalStats", function(msg,done){
    done(null,{success:true, data:{
        global_stats_wr_created:DTs_created,
        global_stats_wr_opened:DTs_created-DTs_closed-DTs_deleted,
        global_stats_wr_closed: DTs_closed}})
})




seneca.listen(5000)