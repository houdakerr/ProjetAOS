const Seneca = require('seneca')

var seneca = Seneca()

var dt = []

/**
 * La fonction syntID d'aide permet de vérifier la suntax de l'id
 * @param {*} msg 
 * @param {*} done 
 * @returns 
 */
function syntID(msg, done){

    //renoyer l'id sous format d'un entier 
    if(typeof msg.id == "string")
        msg.id = parseInt(msg.id,10)

    //si le id exite et il est déja un entier 
    if(msg.id !== undefined && msg.id===parseInt(msg.id,10)){
      
        if(msg.id < dt.length && msg.id >= 0)
            return true
    }
      
    //si l'id dépasse les bornes de dt, on retourne un message d'err
    done(null,{success:false,msg:"wr not found"})
    return false
}

/**
 * La fonction qui permet de retouner la date actuelle sous format d'une chaine de carractère
 * j'ai utiliser celle fournie dans classe de test
 * @returns 
 */

function CurrentDate(){

    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); 
    var yyyy = today.getFullYear();

    today = mm + '/' + dd + '/' + yyyy;
    return today
}

/**
 * CREATE
 * La fonction qui permet de creer une DT
 */
seneca.add("role:wr,cmd:create", function (msg, done){

 //verifier l'existance des trois champs
  if(!msg.applicant||!msg.work||!msg.dc_date){

        done(null,{success:false,msg:"Champ manquant !"})
        return

    }

    dt.push({

        applicant:msg.applicant,
        work:msg.work,
        dc_date:msg.dc_date,
        //initialiser l'état de la DT  a "created"
        state:"created",
        //retourner un id qui sera utiliser par d'autres ops
        id: dt.length,
        //creer compl_date initialement vide car son etat est "created"
        compl_date: undefined})


    //Send asynchrone message to stats-service , with action = "created"
    MsgToStat = {role:"wr-stats",action:"created",data:dt[dt.length-1]}
    seneca.act( MsgToStat)


    done(null,{success: true, data:[dt[dt.length-1]]})
})


/**
 * RETRIEVE
 * La fonction qui permet de retourner une DT ou l'enseble de DTs
 */

seneca.add("role:wr,cmd:retrieve",function (msg, done){
    
     //Si l'id n'est pas specifié on retourne tous les dts
    if(msg.id == undefined){

        done(null,{success:true, data: dt}) 
    }

    //sinon , on retourne une DT qui correspon a l'id spécifié 
    else if(syntID(msg,done))

        done(null,{success:true, data:[dt[msg.id]]}) 
})


/**
 * UPDATE
 * La fonction qui permet de mettre a jour une DT
 * on ne peut modifié que les champs work & state
 */

//le id  (optionel)
seneca.add("role:wr,cmd:update", function(msg,done){
    done(null,{success:false,msg:"wr id not provided"})
})

//si l'id est spécifié 
seneca.add("role:wr,cmd:update,id:*", function (msg, done){

    if(syntID(msg,done)){

        //on ne peut modifié que la DT qui est dans l'état "created"
        if(dt[msg.id].state=="created") {
        
        //on peut modifié  "work" : la description"
            if(msg.work !== undefined)
                dt[msg.id].work = msg.work

        //on peut modifié "state" 
            if(msg.state !== undefined){
                              
                //la valeur state peut etre modifiée seulement a "closed"
                if(msg.state=="closed") {
                    
                    {
                        //compl_date est égale a la date courante 
                        dt[msg.id].compl_date = CurrentDate() 
                        dt[msg.id].state = msg.state

                           //Send asynchrone message to stats-service , with action = "closed"
                        MsgToStat = {role:"wr-stats",action:"closed",data:dt[msg.id]}
                        seneca.act( MsgToStat)
                    }
                   
                        
                }
                 //dans le cas ou l'etat modifié  n'est ni "created" ni "closed" echec 
                else if(msg.state!=="created") {
                    done(null, {success:false,msg:"le champs state peut seulement  etre soit created ou closed !"})
                    return
                }
            }
            done(null, {success:true, data:[dt[msg.id]]})
        }

        else{
           //si la DT est "closed" on ne peut pas la modifié
            done(null,{success:false,msg:"wr is already closed"})

        }
    }
})

/**
 * DELETE
 * La fonction qui permet de supprimer DTs
 */

//pour chaque DTs sans spécifié id 
seneca.add("role:wr,cmd:delete", function (msg, done){
    {
        wrUP = dt
        dt = []
          //pour chaque DT faire
        for(let Id in wrUP) {
            let wr = wrUP[Id]

          //on test si son etat est "closed" on vas la supprimer 
            if(wr.state == "closed"){

                dt.push(wr) 

            }
            //sinon on supprime 
            else {

                //Send asynchrone message to stats-service , with action = "deleted"
                let  MsgToStat = {role:"wr-stats",action:"deleted",data:wr}
                seneca.act( MsgToStat) 

            }
        }

        done(null,{success:true})
    }
})

/**
 * DELETE
 * La fonction qui permet de supprimer DTs
 */

//si le id est spécifié , 
seneca.add("role:wr,cmd:delete,id:*", function (msg, done){
    if(syntID(msg,done)){
        
        //si son etat est created on l'as supprime de la liste
        if(dt[msg.id].state == "created"){
            
            removed = dt[msg.id]
            dt.splice(msg.id,1) 
            
            //Send asynchrone message to stats-servicd , with action = "deleted"
            MsgToStat = {role:"wr-stats",action:"deleted",data:removed}
            seneca.act( MsgToStat)
            done(null,{success:true, data:[removed]})
            return
        }
        else
            done(null,{success:false,msg:"wr is already closed"})
    }
})

seneca.client({port: 5000}) 
//to test with repl //telnet localhost 10001 
seneca.use('repl', {port: 10021})
seneca.listen(4000) 